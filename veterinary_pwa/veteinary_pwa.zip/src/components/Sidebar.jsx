import React from 'react';
import { 
  LayoutDashboard, CalendarDays, Users, Dog, FileHeart,
  CreditCard, Package, BarChart3, Settings, LogOut,
  UserCog, Bell, Pill, Microscope, ClipboardPen, Clock, ClipboardList, Mail,
  ChevronRight, ChevronLeft, Map, CheckCircle2, UserCircle, Car, Headphones, MoreVertical, Activity, Shield
} from 'lucide-react';
import './Sidebar.css';
import { isTabAllowedForPlan } from '../utils/planPermissions';

import { apiFetch } from '../utils/api';

export default function Sidebar({ 
  currentTab, setCurrentTab,
  sidebarOpen, setSidebarOpen,
  currentRole, setCurrentRole,
  onLogout,
  notifications
}) {
  const user = (() => {
    try { return JSON.parse(localStorage.getItem('user') || '{}'); }
    catch (e) { return {}; }
  })();
  const userPlanId = user.plan_id || user.plan || (user.subscription_status === 'trial' ? 'plan-free-trial' : 'plan-starter');

  const [roleMatrix, setRoleMatrix] = React.useState(() => {
    try {
      const stored = localStorage.getItem('petcare_role_matrix');
      return stored ? JSON.parse(stored) : null;
    } catch (e) {
      return null;
    }
  });

  React.useEffect(() => {
    const fetchPerms = async () => {
      try {
        const res = await apiFetch('/api/v1/permissions');
        const data = await res.json();
        if (data.status === 'success' && data.data.matrix) {
          setRoleMatrix(data.data.matrix);
          localStorage.setItem('petcare_role_matrix', JSON.stringify(data.data.matrix));
        }
      } catch (err) {
        // Silently fallback to static defaults
      }
    };
    fetchPerms();

    const handlePermUpdate = (e) => {
      if (e.detail) {
        setRoleMatrix(e.detail);
      } else {
        fetchPerms();
      }
    };
    window.addEventListener('petcare_permissions_updated', handlePermUpdate);
    return () => window.removeEventListener('petcare_permissions_updated', handlePermUpdate);
  }, []);

  const menuItems = [
    { id: 'dashboard',    label: 'Dashboard',             icon: LayoutDashboard, roles: ['Admin','Manager','Doctor','Receptionist','Vet Assistant'] },
    { id: 'appointments', label: currentRole === 'Doctor' || currentRole === 'Vet Assistant' ? 'My Appointments' : 'Appointments', icon: CalendarDays, roles: ['Admin','Manager','Doctor','Receptionist', 'Vet Assistant'] },
    { id: 'home-visits',  label: currentRole === 'Doctor' ? 'Home Visits' : 'Home Visit Appointments', icon: Map,  roles: ['Admin','Manager','Receptionist','Doctor', 'Vet Assistant'] },
    { id: 'hospitalization', label: 'Hospitalization',    icon: ClipboardList,   roles: ['Admin','Manager','Doctor','Receptionist','Vet Assistant'] },
    { id: 'owners',       label: 'Pet Owners',            icon: Users,           roles: ['Admin','Manager','Receptionist'] },
    { id: 'pets',         label: currentRole === 'Doctor' || currentRole === 'Vet Assistant' ? 'Patients' : 'Pets', icon: Dog, roles: ['Admin','Manager','Doctor','Receptionist', 'Vet Assistant'] },
    { id: 'medical',      label: 'Medical Records',       icon: FileHeart,       roles: ['Admin','Manager','Doctor','Vet Assistant'] },
    { id: 'treatment',    label: 'Treatment Notes',       icon: ClipboardPen,    roles: ['Doctor'] },
    { id: 'assistance-tasks', label: 'Assistance Tasks',  icon: CheckCircle2,    roles: ['Vet Assistant'] },
    { id: 'prescriptions',label: 'Prescriptions',         icon: Pill,            roles: ['Doctor'] },
    { id: 'my-revenue',   label: 'My Revenue',            icon: BarChart3,       roles: ['Doctor'] },
    { id: 'billing',      label: 'Billing & POS',         icon: CreditCard,      roles: ['Admin','Manager','Receptionist','Doctor'] },
    { id: 'inventory',    label: 'Inventory',             icon: Package,         roles: ['Admin','Manager','Receptionist'] },
    { id: 'reminders',    label: 'Email Reminders',       icon: Mail,            roles: ['Admin','Manager','Receptionist'] },
    { id: 'staff',        label: 'Staff Management',      icon: UserCog,         roles: ['Admin'] },
    { id: 'permissions',  label: 'Role Permissions',      icon: Shield,          roles: ['Admin', 'Manager'] },
    { id: 'attendance',   label: 'Attendance',            icon: Clock,           roles: ['Admin','Manager'] },
    { id: 'reports',      label: 'Reports & Analytics',   icon: BarChart3,       roles: ['Admin','Manager'] },
    { id: 'settings',     label: currentRole !== 'Admin' ? 'Profile Settings' : 'Settings', icon: Settings, roles: ['Admin', 'Manager', 'Doctor', 'Receptionist', 'Vet Assistant'] },
    { id: 'audit-logs',   label: 'Audit Logs',            icon: Activity,        roles: ['Admin'] },
    { id: 'support',      label: 'Support',               icon: Headphones,      roles: ['Admin'] },
  ];

  const unreadCount = notifications ? notifications.filter(n => !n.read).length : 0;
  const filteredItems = menuItems.filter(item => {
    if (currentRole === 'Admin' || currentRole === 'Super Admin' || currentRole === 'super_admin' || currentRole === 'master_admin') {
      return true;
    }
    if (roleMatrix && roleMatrix[currentRole] && roleMatrix[currentRole][item.id] !== undefined) {
      return Boolean(roleMatrix[currentRole][item.id]);
    }
    return item.roles.includes(currentRole);
  });

  const displayName = user.name || user.fullName || user.clinic_name || ({
    Admin: 'Admin User',
    Manager: 'Clinic Manager',
    Doctor: 'Doctor',
    Receptionist: 'Receptionist',
    'Vet Assistant': 'Vet Assistant'
  }[currentRole] || currentRole || 'User');
  const displayRole = user.role || currentRole || 'Admin';

  const isActive = (id) => currentTab === id;

  // Custom multi-color logic based on item id to mimic the screenshot
  const getIconColor = (id, active) => {
    if (active) return '#2dd4bf'; // Active is always teal
    
    // Assign some colorful defaults mimicking the screenshot
    const colors = {
      'dashboard': '#f59e0b',
      'appointments': '#3b82f6',
      'home-visits': '#ef4444',
      'hospitalization': '#10b981',
      'owners': '#a855f7',
      'pets': '#ec4899',
      'medical': '#ef4444',
      'treatment': '#f59e0b',
      'assistance-tasks': '#10b981',
      'prescriptions': '#3b82f6',
      'billing': '#8b5cf6',
      'inventory': '#ef4444',
      'staff': '#a855f7',
      'reports': '#10b981',
      'settings': '#94a3b8',
      'audit-logs': '#0ea5e9',
      'support': '#f97316'
    };
    return colors[id] || '#94a3b8';
  };

  return (
    <>
      {sidebarOpen && (
        <div
          className="sidebar-overlay"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside 
        className={`sidebar-premium ${sidebarOpen ? 'open' : 'closed'}`}
        style={{ width: sidebarOpen ? '280px' : '80px' }}
      >
        <div className="sidebar-brand-container">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', overflow: 'hidden' }}>
            {/* KT Image Logo */}
            <img 
              src="/kt-logo.png" 
              alt="KT Logo" 
              style={{
                width: '40px',
                height: 'auto',
                flexShrink: 0,
                objectFit: 'contain'
              }}
            />

            {sidebarOpen && (
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <span style={{ fontSize: '1.05rem', fontWeight: 600, color: '#f8fafc', whiteSpace: 'nowrap' }}>
                  PetCare <span style={{ color: '#2dd4bf' }}>Pro</span>
                </span>
                <span style={{ fontSize: '0.65rem', color: '#64748b', whiteSpace: 'nowrap' }}>
                  Clinic Management System
                </span>
              </div>
            )}
          </div>

          <button 
            className="sidebar-collapse-btn"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <span className="desktop-icon" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
              {sidebarOpen ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
            </span>
            <span className="mobile-icon" style={{ display: 'none', alignItems: 'center', justifyContent: 'center' }}>
              <MoreVertical size={14} />
            </span>
          </button>
        </div>

        <nav className="sidebar-nav-menu">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.id);
            const isAllowed = isTabAllowedForPlan(item.id, userPlanId);

            return (
              <button 
                key={item.id}
                className={`sidebar-menu-btn ${active ? 'active' : ''}`}
                onClick={() => { setCurrentTab(item.id); if (window.innerWidth <= 1024) setSidebarOpen(false); }}
                title={!isAllowed ? `${item.label} (Locked in your plan)` : item.label}
                style={!isAllowed ? { opacity: 0.78 } : {}}
              >
                <div className="sidebar-menu-icon" style={{ color: getIconColor(item.id, active) }}>
                  <Icon size={20} />
                </div>
                {sidebarOpen && (
                  <>
                    <span className="sidebar-menu-label" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                      <span>{item.label}</span>
                      {!isAllowed && (
                        <span style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '3px',
                          backgroundColor: 'rgba(245, 158, 11, 0.15)',
                          color: '#fbbf24',
                          fontSize: '0.65rem',
                          fontWeight: 700,
                          padding: '2px 6px',
                          borderRadius: '4px',
                          border: '1px solid rgba(245, 158, 11, 0.3)',
                          marginLeft: '6px'
                        }}>
                          🔒 Lock
                        </span>
                      )}
                    </span>
                    {isAllowed && <ChevronRight size={16} className="chevron" />}
                  </>
                )}
              </button>
            );
          })}

          <button 
            className={`sidebar-menu-btn ${isActive('notifications') ? 'active' : ''}`}
            onClick={() => { setCurrentTab('notifications'); if (window.innerWidth <= 1024) setSidebarOpen(false); }}
            title="Notifications"
          >
            <div className="sidebar-menu-icon" style={{ position: 'relative', color: getIconColor('notifications', isActive('notifications')) }}>
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="notification-badge">{unreadCount}</span>
              )}
            </div>
            {sidebarOpen && (
              <>
                <span className="sidebar-menu-label">Notifications</span>
                <ChevronRight size={16} className="chevron" />
              </>
            )}
          </button>
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-user-avatar">
            <UserCircle size={24} color="#94a3b8" />
            <div className="online-dot"></div>
          </div>
          {sidebarOpen && (
            <>
              <div className="sidebar-user-info">
                <div className="sidebar-user-name">{displayName}</div>
                <div className="sidebar-user-role">{displayRole}</div>
              </div>
              <button onClick={onLogout} className="logout-btn" title="Logout">
                <LogOut size={16} />
              </button>
            </>
          )}
        </div>
      </aside>
    </>
  );
}
