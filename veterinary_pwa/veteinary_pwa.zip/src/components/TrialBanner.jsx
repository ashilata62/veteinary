import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';

export default function TrialBanner() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('user') || '{}');
    } catch (e) {
      return {};
    }
  });

  useEffect(() => {
    const handleUpdate = () => {
      try {
        setUserData(JSON.parse(localStorage.getItem('user') || '{}'));
      } catch (e) {}
    };

    window.addEventListener('storage', handleUpdate);
    window.addEventListener('auth:subscription_status', handleUpdate);
    return () => {
      window.removeEventListener('storage', handleUpdate);
      window.removeEventListener('auth:subscription_status', handleUpdate);
    };
  }, []);

  const user = userData;
  if (!user || !user.id || user.role === 'SuperAdmin' || localStorage.getItem('sa_token')) return null;

  const status = (user.subscription_status || '').toLowerCase();
  const planId = (user.plan_id || user.plan || '').toLowerCase();

  // Show banner if subscription_status is 'trial' or plan is free-trial or not explicitly paid active
  const isPaid = status === 'active' && planId !== 'plan-free-trial' && planId !== 'free-trial';
  const isTrial = !isPaid && (status === 'trial' || planId === 'plan-free-trial' || planId === 'free-trial' || !status);
  
  if (!isTrial) return null;

  // Helper to parse dates strictly as local calendar midnight
  const parseMid = (val) => {
    if (!val) return null;
    if (val instanceof Date) {
      return new Date(val.getFullYear(), val.getMonth(), val.getDate());
    }
    if (typeof val === 'string') {
      const trimmed = val.trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
        const [y, m, d] = trimmed.split('-').map(Number);
        return new Date(y, m - 1, d);
      }
      const dt = new Date(val);
      if (!isNaN(dt.getTime())) {
        return new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
      }
    }
    return null;
  };

  const today = new Date();
  const todayMid = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const startMid = parseMid(user.trial_start_date || user.created_at) || todayMid;
  let endMid = parseMid(user.trial_end_date || user.trialEndDate || user.trial_expires_at);

  if (!endMid && startMid) {
    const defaultEnd = new Date(startMid);
    defaultEnd.setDate(defaultEnd.getDate() + 7);
    endMid = defaultEnd;
  }

  let totalDays = 7;
  let diffDays = 7;
  let currentDay = 1;

  if (endMid) {
    totalDays = Math.max(1, Math.round((endMid - startMid) / (1000 * 60 * 60 * 24))) || 7;
    const daysPassed = Math.max(0, Math.round((todayMid - startMid) / (1000 * 60 * 60 * 24)));
    diffDays = Math.max(0, Math.round((endMid - todayMid) / (1000 * 60 * 60 * 24)));
    currentDay = Math.min(totalDays, daysPassed + 1);

    // If backend provided pre-calculated values, use them
    if (typeof user.trial_days_left === 'number') {
      diffDays = user.trial_days_left;
    }
    if (typeof user.trial_current_day === 'number') {
      currentDay = user.trial_current_day;
    }

    // If trial is completely over, the TrialExpired page/modal takes over
    if (diffDays <= 0 && status === 'expired') return null;
  }

  const formattedRegDate = startMid 
    ? startMid.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
    : 'Recently';

  const formattedEndDate = endMid
    ? endMid.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
    : '';

  return (
    <div 
      className="trial-banner"
      style={{
        background: 'linear-gradient(90deg, #042f2e 0%, #064e3b 40%, #0f766e 100%)',
        color: '#ecfdf5',
        padding: '12px 22px',
        margin: '0 0 18px 0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '14px',
        borderRadius: '14px',
        border: '1px solid rgba(45, 212, 191, 0.3)',
        boxShadow: '0 4px 16px rgba(15, 118, 110, 0.2)',
        flexWrap: 'wrap'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
        <span 
          style={{
            backgroundColor: '#fbbf24',
            color: '#78350f',
            padding: '4px 14px',
            borderRadius: '9999px',
            fontSize: '0.75rem',
            fontWeight: '800',
            letterSpacing: '0.5px',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '5px',
            textTransform: 'uppercase',
            boxShadow: '0 2px 5px rgba(0,0,0,0.15)'
          }}
        >
          <Sparkles size={13} /> 7-Day Free Trial
        </span>

        <span style={{ fontSize: '0.88rem', fontWeight: 500, color: '#f0fdfa' }}>
          Registered on <strong>{formattedRegDate}</strong> • Day <strong>{currentDay} of 7</strong>
          <span style={{ margin: '0 10px', opacity: 0.5 }}>|</span>
          <span style={{ color: '#5eead4', fontWeight: '800' }}>
            ⏳ {diffDays} {diffDays === 1 ? 'Day' : 'Days'} Remaining
          </span>
          {formattedEndDate && (
            <span style={{ opacity: 0.85, fontSize: '0.8rem', marginLeft: '6px' }}>
              (Expires {formattedEndDate})
            </span>
          )}
        </span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <button 
          onClick={() => navigate('/plans')}
          style={{
            backgroundColor: '#fbbf24',
            color: '#78350f',
            border: 'none',
            borderRadius: '20px',
            padding: '7px 20px',
            fontSize: '0.84rem',
            fontWeight: '800',
            cursor: 'pointer',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            boxShadow: '0 3px 10px rgba(251, 191, 36, 0.35)',
            transition: 'all 0.2s ease',
            whiteSpace: 'nowrap'
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.backgroundColor = '#f59e0b';
            e.currentTarget.style.transform = 'translateY(-1px)';
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.backgroundColor = '#fbbf24';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          Upgrade Plan / Buy Now <ArrowRight size={14} strokeWidth={2.5} />
        </button>
      </div>
    </div>
  );
}
