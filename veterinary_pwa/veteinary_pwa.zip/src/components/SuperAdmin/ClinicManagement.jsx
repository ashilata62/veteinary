import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../utils/api';
import { 
  Building2, Search, Edit, Trash2, Power, 
  Plus, CheckCircle, AlertTriangle, ShieldCheck, Mail, X, UserCheck
} from 'lucide-react';

export default function ClinicManagement() {
  const [clinics, setClinics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedClinic, setSelectedClinic] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  useEffect(() => {
    const fetchClinics = async () => {
      try {
        const response = await apiFetch('/api/super-admin/clinics');
        const data = await response.json();
        if (data.status === 'success' && Array.isArray(data.data)) {
          setClinics(data.data);
        } else {
          setClinics([]);
        }
      } catch (error) {
        console.error('Failed to fetch clinics', error);
        setClinics([]);
      } finally {
        setLoading(false);
      }
    };
    fetchClinics();
  }, []);

  const handleToggleStatus = async (id) => {
    const target = clinics.find(c => c.id === id);
    if (!target) return;
    const currentStatus = target.subStatus || target.subscriptionStatus || target.status || 'Active';
    const isCurrentlyActive = currentStatus === 'Active' || currentStatus === 'ACTIVE' || currentStatus === 'Trial' || currentStatus === 'trial';
    const action = isCurrentlyActive ? 'suspend' : 'activate';
    
    try {
      const res = await apiFetch(`/api/super-admin/clinics/${id}/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: isCurrentlyActive ? 'Suspended by SuperAdmin' : 'Reactivated by SuperAdmin' })
      });
      const data = await res.json();
      if (data.status === 'success') {
        const newStatus = isCurrentlyActive ? 'Suspended' : 'Active';
        setClinics(prev => prev.map(c => c.id === id ? { ...c, subStatus: newStatus, subscriptionStatus: newStatus, status: newStatus } : c));
        showToast(data.message || `Clinic status updated to ${newStatus}`);
      } else {
        showToast(data.message || 'Failed to update status');
      }
    } catch (err) {
      console.error('Error toggling clinic status:', err);
      showToast('Error updating clinic status');
    }
  };

  const handleDeleteClinic = async (id, name) => {
    if (!window.confirm(`Are you sure you want to permanently delete clinic "${name}" and all its records? This cannot be undone.`)) {
      return;
    }

    try {
      const res = await apiFetch(`/api/super-admin/clinics/${id}`, {
        method: 'DELETE'
      });
      const data = await res.json();
      if (data.status === 'success') {
        setClinics(prev => prev.filter(c => c.id !== id));
        showToast(`Clinic "${name}" deleted successfully.`);
      } else {
        showToast(data.message || 'Failed to delete clinic');
      }
    } catch (err) {
      console.error('Error deleting clinic:', err);
      showToast('Network error while deleting clinic');
    }
  };

  const handleSaveEdit = async (e) => {
    e.preventDefault();
    if (!selectedClinic) return;

    try {
      const res = await apiFetch(`/api/super-admin/clinics/${selectedClinic.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(selectedClinic)
      });
      const data = await res.json();
      if (data.status === 'success') {
        setClinics(prev => prev.map(c => c.id === selectedClinic.id ? selectedClinic : c));
        setIsEditModalOpen(false);
        showToast('Clinic details updated successfully.');
      } else {
        showToast(data.message || 'Failed to save changes');
      }
    } catch (err) {
      console.error('Error updating clinic:', err);
      showToast('Network error while saving clinic');
    }
  };

  // Normalize data — handle both API fields and default data fields
  const normalizedClinics = clinics.map(c => ({
    ...c,
    name: c.name || c.clinic_name || 'Unknown Clinic',
    adminName: c.adminName || c.admin_name || 'Unknown Admin',
    email: c.email || c.adminEmail || '',
    phone: c.phone || '',
    subStatus: c.subStatus || c.subscriptionStatus || 'Unknown',
    currentPlan: c.currentPlan || c.planName || 'No Plan',
    expiryDate: c.expiryDate || c.subscriptionEnd || '—',
  }));

  const filteredClinics = normalizedClinics.filter(c => {
    const name = (c.name || '').toLowerCase();
    const adminName = (c.adminName || '').toLowerCase();
    const email = (c.email || '').toLowerCase();
    const matchesSearch = name.includes(search.toLowerCase()) ||
      adminName.includes(search.toLowerCase()) ||
      email.includes(search.toLowerCase());
    
    if (statusFilter === 'All') return matchesSearch;
    if (statusFilter === 'Active') return matchesSearch && c.subStatus === 'Active';
    if (statusFilter === 'Trial') return matchesSearch && (c.subStatus === 'Trial' || c.subStatus === 'trial');
    if (statusFilter === 'Suspended') return matchesSearch && (c.subStatus === 'Suspended' || c.subStatus === 'suspended');
    return matchesSearch;
  });

  return (
    <div className="sa-dash-wrapper">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="sa-toast">
          <CheckCircle size={16} color="#0d9488" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Page Header */}
      <div className="sa-page-header">
        <div>
          <h1 className="sa-dash-title">Admins & Clinic Management</h1>
          <p className="sa-dash-subtitle">View, edit, suspend or upgrade platform clinic administrators.</p>
        </div>
        <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
          <div className="sa-search-bar">
            <Search size={16} className="sa-search-icon" />
            <input type="text" placeholder="Search clinic or admin..." value={search} onChange={(e) => setSearch(e.target.value)} className="sa-search-input" />
          </div>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sa-filter-select">
            <option value="All">All Statuses</option>
            <option value="Active">Active Paid</option>
            <option value="Trial">Free Trial</option>
            <option value="Suspended">Suspended</option>
          </select>
        </div>
      </div>

      {/* Main Table */}
      <div className="sa-renewals-card">
        <div className="sa-table-responsive">
          <table className="sa-renewals-table">
            <thead>
              <tr>
                <th>Clinic & Admin Details</th>
                <th>Contact</th>
                <th>Current Plan</th>
                <th>Status</th>
                <th>Renewal / Expiry</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="6" style={{ padding: '2rem', textAlign: 'center', color: '#64748b' }}>Loading Clinics...</td></tr>
              ) : filteredClinics.length === 0 ? (
                <tr><td colSpan="6" style={{ padding: '2rem', textAlign: 'center', color: '#64748b' }}>No clinics found matching criteria.</td></tr>
              ) : (
                filteredClinics.map((clinic) => (
                  <tr key={clinic.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
                        <div style={{
                          width: '42px', height: '42px', borderRadius: '10px',
                          backgroundColor: '#f0fdfa', border: '1px solid #ccfbf1', color: '#0d9488',
                          display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700
                        }}>
                          <Building2 size={20} />
                        </div>
                        <div>
                          <div style={{ fontWeight: 700, color: '#0f172a' }}>{clinic.name}</div>
                          <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Admin: {clinic.adminName}</div>
                        </div>
                      </div>
                    </td>

                    <td>
                      <div style={{ fontSize: '0.85rem', color: '#334155', fontWeight: 500 }}>{clinic.email}</div>
                      <div style={{ fontSize: '0.775rem', color: '#94a3b8' }}>{clinic.phone}</div>
                    </td>

                    <td>
                      <span className={`sa-plan-badge ${clinic.currentPlan.toLowerCase().includes('pro') ? 'pro' : clinic.currentPlan.toLowerCase().includes('trial') ? 'trial' : 'enterprise'}`}>
                        {clinic.currentPlan}
                      </span>
                    </td>

                    <td>
                      <span style={{
                        padding: '0.3rem 0.75rem', borderRadius: '999px', fontSize: '0.775rem', fontWeight: 700,
                        backgroundColor: clinic.subStatus === 'Active' ? '#dcfce7' : clinic.subStatus === 'Trial' ? '#fef3c7' : '#fee2e2',
                        color: clinic.subStatus === 'Active' ? '#15803d' : clinic.subStatus === 'Trial' ? '#b45309' : '#b91c1c'
                      }}>
                        {clinic.subStatus}
                      </span>
                    </td>

                    <td className="sa-td-expiry">
                      {clinic.expiryDate}
                    </td>

                    <td>
                      <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                        <button 
                          onClick={() => { setSelectedClinic(clinic); setIsEditModalOpen(true); }}
                          style={{ background: '#f1f5f9', border: 'none', padding: '0.45rem', borderRadius: '6px', cursor: 'pointer', color: '#0f766e' }} 
                          title="Edit Admin"
                        >
                          <Edit size={16} />
                        </button>
                        <button 
                          onClick={() => handleToggleStatus(clinic.id)}
                          style={{ 
                            background: clinic.subStatus === 'Active' ? '#fef2f2' : '#f0fdf4', 
                            border: 'none', padding: '0.45rem', borderRadius: '6px', cursor: 'pointer', 
                            color: clinic.subStatus === 'Active' ? '#ef4444' : '#16a34a' 
                          }} 
                          title={clinic.subStatus === 'Active' ? 'Suspend' : 'Activate'}
                        >
                          <Power size={16} />
                        </button>
                        <button 
                          onClick={() => handleDeleteClinic(clinic.id, clinic.name)}
                          style={{ background: '#fef2f2', border: 'none', padding: '0.45rem', borderRadius: '6px', cursor: 'pointer', color: '#dc2626' }} 
                          title="Delete Admin"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Modal */}
      {isEditModalOpen && selectedClinic && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(15,23,42,0.6)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem'
        }}>
          <div style={{
            backgroundColor: '#ffffff', borderRadius: '16px', padding: '1.75rem', width: '100%', maxWidth: '520px',
            boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)', border: '1px solid #e2e8f0'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#0f172a', margin: 0 }}>Edit Clinic Admin</h3>
              <button onClick={() => setIsEditModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b' }}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>Clinic Name</label>
                <input 
                  type="text" 
                  value={selectedClinic.name} 
                  onChange={(e) => setSelectedClinic({ ...selectedClinic, name: e.target.value })}
                  style={{ width: '100%', padding: '0.6rem 0.85rem', borderRadius: '8px', border: '1px solid #cbd5e1', outline: 'none' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>Admin Name</label>
                <input 
                  type="text" 
                  value={selectedClinic.adminName} 
                  onChange={(e) => setSelectedClinic({ ...selectedClinic, adminName: e.target.value })}
                  style={{ width: '100%', padding: '0.6rem 0.85rem', borderRadius: '8px', border: '1px solid #cbd5e1', outline: 'none' }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>Email</label>
                  <input 
                    type="email" 
                    value={selectedClinic.email} 
                    onChange={(e) => setSelectedClinic({ ...selectedClinic, email: e.target.value })}
                    style={{ width: '100%', padding: '0.6rem 0.85rem', borderRadius: '8px', border: '1px solid #cbd5e1', outline: 'none' }}
                  />
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>Plan</label>
                  <select 
                    value={selectedClinic.currentPlan} 
                    onChange={(e) => setSelectedClinic({ ...selectedClinic, currentPlan: e.target.value })}
                    style={{ width: '100%', padding: '0.6rem 0.85rem', borderRadius: '8px', border: '1px solid #cbd5e1', outline: 'none' }}
                  >
                    <option value="7-Day Trial">7-Day Trial</option>
                    <option value="Monthly Pro">Monthly Pro</option>
                    <option value="Yearly Enterprise">Yearly Enterprise</option>
                  </select>
                </div>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>Subscription Status</label>
                <select 
                  value={selectedClinic.subStatus} 
                  onChange={(e) => setSelectedClinic({ ...selectedClinic, subStatus: e.target.value })}
                  style={{ width: '100%', padding: '0.6rem 0.85rem', borderRadius: '8px', border: '1px solid #cbd5e1', outline: 'none' }}
                >
                  <option value="Active">Active Paid</option>
                  <option value="Trial">Trial</option>
                  <option value="Suspended">Suspended</option>
                </select>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1rem' }}>
                <button type="button" onClick={() => setIsEditModalOpen(false)} style={{ padding: '0.6rem 1.25rem', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#fff', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '0.6rem 1.25rem', borderRadius: '8px', border: 'none', background: '#14b8a6', color: '#fff', fontWeight: 600, cursor: 'pointer' }}>Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
